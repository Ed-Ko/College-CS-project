# Lab2 CHANGELOG

## v1
### CO_Lab_2.pdf
- [Requirements] Specify zero extension or sign extension in I-type instruction set to prevent confusion .
- [Testing] Fix the compiling command and run testbench interchange.

### Reg_File.v
- Change the value of `Reg_File[10]` and `Reg_File[11]` in `Reg_File.v` to `-1` and `-2` respectively.

### _CO_Lab2_test_data_slt.txt
- Fix the answer of `r2` register from `0` to `1`

## v0
Initial release